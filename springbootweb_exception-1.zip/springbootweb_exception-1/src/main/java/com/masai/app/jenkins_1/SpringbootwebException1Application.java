package com.masai.app.jenkins_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootwebException1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootwebException1Application.class, args);
	}

}
