package com.masai.app.jenkins_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootwebException1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
